import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider, useAuth } from "./hooks/use-auth";
import { ThemeProvider } from "./hooks/use-theme";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login-page";
import SignupPage from "@/pages/signup-page";
import HomePage from "@/pages/home-page";
import DoctorsPage from "@/pages/doctors-page";
import AppointmentPage from "@/pages/appointment-page";
import AppointmentsListPage from "@/pages/appointments-list-page";
import ProfilePage from "@/pages/profile-page";
import SettingsPage from "@/pages/settings-page";

function Router() {
  const { user, isLoading } = useAuth();

  // Show loading indicator while checking auth status
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={user ? HomePage : LoginPage} />
      <Route path="/signup" component={SignupPage} />
      <Route path="/login" component={LoginPage} />
      
      {/* Protected routes */}
      {user ? (
        <>
          <Route path="/home" component={HomePage} />
          <Route path="/doctors" component={DoctorsPage} />
          <Route path="/appointment" component={AppointmentPage} />
          <Route path="/appointments" component={AppointmentsListPage} />
          <Route path="/profile" component={ProfilePage} />
          <Route path="/settings" component={SettingsPage} />
        </>
      ) : (
        // Redirect to login if not authenticated
        <Route>{() => {
          window.location.href = "/";
          return null;
        }}</Route>
      )}
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
