import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/hooks/use-auth";
import { 
  User, 
  LogOut, 
  Settings, 
  Calendar, 
  UserPlus, 
  MapPin, 
  Phone,
  Building,
  ClipboardList,
  X,
  ChevronRight,
  Stethoscope,
  Clock
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
  DialogFooter
} from "@/components/ui/dialog";

// Define the hospital interface
interface Hospital {
  id: number;
  name: string;
  location: string;
  specialties: string[];
  contact: string;
  image?: string; // URL for the hospital image
}

// List of top hospitals in India
const topHospitals: Hospital[] = [
  { 
    id: 1, 
    name: "AIIMS", 
    location: "Delhi", 
    specialties: ["Cardiology", "Neurology", "Oncology"], 
    contact: "+91-11-2658-8500",
    image: "https://img.freepik.com/free-photo/medium-shot-doctor-with-crossed-arms_23-2148868176.jpg"
  },
  { 
    id: 2, 
    name: "Apollo Hospitals", 
    location: "Chennai", 
    specialties: ["Cardiology", "Orthopedics", "Transplant"], 
    contact: "+91-44-2829-3333",
    image: "https://img.freepik.com/free-photo/doctor-with-his-arms-crossed-white-background_1368-5790.jpg"
  },
  { 
    id: 3, 
    name: "Fortis Hospital", 
    location: "Mumbai", 
    specialties: ["Cardiology", "Orthopedics", "Neurology"], 
    contact: "+91-22-4925-4925",
    image: "https://img.freepik.com/free-photo/pleased-young-female-doctor-wearing-medical-robe-stethoscope-around-neck-standing-with-closed-posture_409827-254.jpg"
  },
  { 
    id: 4, 
    name: "Medanta", 
    location: "Gurugram", 
    specialties: ["Cardiology", "Neurology", "Gastroenterology"], 
    contact: "+91-124-4141-414",
    image: "https://img.freepik.com/free-photo/portrait-smiling-handsome-male-doctor-man_171337-5055.jpg"
  },
  { 
    id: 5, 
    name: "Manipal Hospital", 
    location: "Bengaluru", 
    specialties: ["Oncology", "Cardiology", "Nephrology"], 
    contact: "+91-80-2502-4444",
    image: "https://img.freepik.com/free-photo/smiling-doctor-with-strethoscope-isolated-grey_651396-974.jpg"
  },
  { 
    id: 6, 
    name: "KIMS", 
    location: "Hyderabad", 
    specialties: ["Cardiology", "Orthopedics", "Neurology"], 
    contact: "+91-40-4488-5000",
    image: "https://img.freepik.com/free-photo/medical-workers-covid-19-vaccination-concept-confident-professional-doctor-female-nurse-blue-scrubs-stethoscope-show-thumbs-up-assure-guarantee-best-quality-service-clinic_1258-57360.jpg"
  },
  { 
    id: 7, 
    name: "Max Hospital", 
    location: "Noida", 
    specialties: ["Oncology", "Cardiology", "Orthopedics"], 
    contact: "+91-120-4622-222",
    image: "https://img.freepik.com/free-photo/african-american-medical-doctor-man-with-mask-isolated-people-with-medical-insurance_1157-47284.jpg"
  },
  { 
    id: 8, 
    name: "Narayana Health", 
    location: "Kolkata", 
    specialties: ["Cardiology", "Gastroenterology", "Neurology"], 
    contact: "+91-33-7122-2222",
    image: "https://img.freepik.com/free-photo/young-handsome-physician-medical-robe-with-stethoscope_1303-17818.jpg"
  },
  { 
    id: 9, 
    name: "Ruby Hall Clinic", 
    location: "Pune", 
    specialties: ["Cardiology", "Neurology", "Orthopedics"], 
    contact: "+91-20-6645-5555",
    image: "https://img.freepik.com/free-photo/female-doctor-hospital-with-stethoscope_23-2148827776.jpg"
  },
  { 
    id: 10, 
    name: "Sir Ganga Ram Hospital", 
    location: "Delhi", 
    specialties: ["Gastroenterology", "Neurology", "Urology"], 
    contact: "+91-11-2586-1002",
    image: "https://img.freepik.com/free-photo/doctors-stethoscopes-white-uniforms-standing-corridor-hospital_1303-21204.jpg"
  },
  { 
    id: 11, 
    name: "Christian Medical College", 
    location: "Vellore", 
    specialties: ["Cardiology", "Neurology", "Hematology"], 
    contact: "+91-416-228-2010",
    image: "https://img.freepik.com/free-photo/medical-concept-indian-beautiful-female-doctor-white-coat-with-stethoscope-waist-up-medical-service-healthcare-hospital_1157-55863.jpg"
  },
  { 
    id: 12, 
    name: "Jaslok Hospital", 
    location: "Mumbai", 
    specialties: ["Oncology", "Nephrology", "Neurology"], 
    contact: "+91-22-6657-3010",
    image: "https://img.freepik.com/free-photo/portrait-doctor_144627-39390.jpg"
  },
  { 
    id: 13, 
    name: "Hinduja Hospital", 
    location: "Mumbai", 
    specialties: ["Cardiology", "Neurology", "Oncology"], 
    contact: "+91-22-6751-1000",
    image: "https://img.freepik.com/free-photo/beautiful-young-female-doctor-looking-camera-office_1301-7807.jpg"
  },
  { 
    id: 14, 
    name: "Lilavati Hospital", 
    location: "Mumbai", 
    specialties: ["Cardiology", "Neurology", "Nephrology"], 
    contact: "+91-22-6693-1000",
    image: "https://img.freepik.com/free-photo/front-view-covid-recovery-center-female-doctor-with-stethoscope_23-2148847898.jpg"
  },
  { 
    id: 15, 
    name: "Sanjay Gandhi PGI", 
    location: "Lucknow", 
    specialties: ["Cardiology", "Neurology", "Gastroenterology"], 
    contact: "+91-522-2494-200",
    image: "https://img.freepik.com/free-photo/confident-doctor-standing-with-folder_23-2147896069.jpg"
  },
];

export default function HomePage() {
  const [, setLocation] = useLocation();
  const { logout } = useAuth();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);

  // Function to handle booking appointment from hospital details
  const handleBookAppointment = () => {
    setLocation("/appointment");
  };
  
  // Function to handle user logout
  const handleLogout = () => {
    logout();
    setIsProfileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header with navigation */}
      <header className="sticky top-0 z-10 bg-white shadow-md py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Medicare</h1>
          
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 transition-colors"
            >
              <User className="h-6 w-6 text-blue-600" />
            </button>
            
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-20 border border-gray-100">
                <button 
                  onClick={() => setLocation("/profile")}
                  className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left"
                >
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </button>
                <button 
                  onClick={() => setLocation("/settings")}
                  className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </button>
                <hr className="my-1 border-gray-200" />
                <button 
                  onClick={() => {
                    handleLogout();
                    setLocation("/");
                  }}
                  className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 w-full text-left"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Welcome section */}
        <section className="mb-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Welcome to Medicare
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Book your appointment easily and get the best healthcare services from top hospitals across India.
          </p>
        </section>

        {/* Action buttons */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-6xl mx-auto">
          <Card className="transition-transform hover:scale-105 border-0 shadow-lg">
            <CardHeader className="pb-4 pt-6 bg-blue-600 text-white rounded-t-lg">
              <CardTitle className="text-xl font-semibold">View Doctors</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <UserPlus className="h-16 w-16 text-blue-600" />
              </div>
              <CardDescription className="text-center text-gray-600">
                Browse through our network of specialist doctors and find the right one for your needs.
              </CardDescription>
            </CardContent>
            <CardFooter className="pb-6">
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => setLocation("/doctors")}
              >
                View Doctors
              </Button>
            </CardFooter>
          </Card>

          <Card className="transition-transform hover:scale-105 border-0 shadow-lg">
            <CardHeader className="pb-4 pt-6 bg-blue-600 text-white rounded-t-lg">
              <CardTitle className="text-xl font-semibold">Book Appointment</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <Calendar className="h-16 w-16 text-blue-600" />
              </div>
              <CardDescription className="text-center text-gray-600">
                Schedule an appointment with your preferred doctor at your convenient time.
              </CardDescription>
            </CardContent>
            <CardFooter className="pb-6">
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => setLocation("/appointment")}
              >
                Book Appointment
              </Button>
            </CardFooter>
          </Card>

          <Card className="transition-transform hover:scale-105 border-0 shadow-lg">
            <CardHeader className="pb-4 pt-6 bg-blue-600 text-white rounded-t-lg">
              <CardTitle className="text-xl font-semibold">My Appointments</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex justify-center mb-4">
                <ClipboardList className="h-16 w-16 text-blue-600" />
              </div>
              <CardDescription className="text-center text-gray-600">
                View and manage your upcoming scheduled appointments with doctors.
              </CardDescription>
            </CardContent>
            <CardFooter className="pb-6">
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => setLocation("/appointments")}
              >
                View Appointments
              </Button>
            </CardFooter>
          </Card>
        </section>

        {/* Top Hospitals Section */}
        <section className="mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <Building className="mr-2 h-6 w-6 text-blue-600" />
            Top Hospitals in India
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {topHospitals.map((hospital) => (
              <Card key={hospital.id} className="hover:shadow-md transition-shadow border border-gray-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-bold text-blue-600">{hospital.name}</CardTitle>
                  <div className="flex items-center text-gray-500 text-sm">
                    <MapPin className="h-4 w-4 mr-1" />
                    {hospital.location}
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex flex-wrap gap-1 mb-2">
                    {hospital.specialties.slice(0, 2).map((specialty, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-blue-50 text-blue-700 text-xs rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center text-gray-500 text-sm mt-2">
                    <Phone className="h-4 w-4 mr-1" />
                    {hospital.contact}
                  </div>
                </CardContent>
                <CardFooter>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="w-full text-blue-600 border-blue-600 hover:bg-blue-50"
                        onClick={() => setSelectedHospital(hospital)}
                      >
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-2xl">
                      <DialogHeader>
                        <DialogTitle className="text-2xl font-bold text-blue-600 flex items-center">
                          <Building className="mr-2 h-5 w-5" />
                          {hospital.name}
                        </DialogTitle>
                        <DialogDescription className="text-gray-600 text-sm">
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1 inline" />
                            {hospital.location}, India
                          </div>
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Image Column */}
                        <div className="flex flex-col space-y-4">
                          <div className="overflow-hidden rounded-lg h-52 w-full">
                            <img 
                              src={hospital.image || "https://img.freepik.com/free-photo/portrait-smiling-male-doctor_171337-1532.jpg"} 
                              alt={`Doctor at ${hospital.name}`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          
                          <div className="border rounded-lg p-4 bg-gray-50">
                            <h4 className="font-medium text-gray-700 flex items-center mb-2">
                              <Stethoscope className="h-4 w-4 mr-2 text-blue-600" />
                              Specialties
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {hospital.specialties.map((specialty, index) => (
                                <span
                                  key={index}
                                  className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full"
                                >
                                  {specialty}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        {/* Details Column */}
                        <div className="flex flex-col space-y-6">
                          <div>
                            <h4 className="font-medium text-gray-700 flex items-center mb-2">
                              <User className="h-4 w-4 mr-2 text-blue-600" />
                              About {hospital.name}
                            </h4>
                            <p className="text-gray-600 text-sm">
                              {hospital.name} is a leading healthcare institution in {hospital.location}, 
                              providing exceptional patient care with state-of-the-art facilities. 
                              The hospital is renowned for its expertise in {hospital.specialties.slice(0, 2).join(" and ")}.
                            </p>
                          </div>
                          
                          <div>
                            <h4 className="font-medium text-gray-700 flex items-center mb-2">
                              <Clock className="h-4 w-4 mr-2 text-blue-600" />
                              Working Hours
                            </h4>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div className="text-gray-700">Monday - Friday:</div>
                              <div className="text-gray-600">8:00 AM - 8:00 PM</div>
                              <div className="text-gray-700">Saturday:</div>
                              <div className="text-gray-600">9:00 AM - 6:00 PM</div>
                              <div className="text-gray-700">Sunday:</div>
                              <div className="text-gray-600">10:00 AM - 4:00 PM</div>
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="font-medium text-gray-700 flex items-center mb-2">
                              <Phone className="h-4 w-4 mr-2 text-blue-600" />
                              Contact Information
                            </h4>
                            <p className="text-gray-600 text-sm mb-1">
                              <span className="font-semibold">Phone:</span> {hospital.contact}
                            </p>
                            <p className="text-gray-600 text-sm">
                              <span className="font-semibold">Email:</span> info@{hospital.name.toLowerCase().replace(/\s+/g, '')}hospital.com
                            </p>
                          </div>
                          
                          <div className="flex flex-col gap-3">
                            <Button 
                              className="w-full bg-blue-600 hover:bg-blue-700"
                              onClick={handleBookAppointment}
                            >
                              Book Appointment
                            </Button>
                            
                            <DialogClose asChild>
                              <Button 
                                variant="outline" 
                                className="w-full border-blue-600 text-blue-600 hover:bg-blue-50"
                              >
                                Back
                              </Button>
                            </DialogClose>
                          </div>
                        </div>
                      </div>
                      
                      <DialogFooter className="mt-6 flex items-center justify-end gap-2">
                        <div className="text-sm text-gray-500">
                          Click "Book Appointment" to schedule a visit or "Back" to return
                        </div>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardFooter>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="bg-gray-50 py-8 border-t border-gray-200">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; {new Date().getFullYear()} Medicare. All rights reserved.</p>
          <p className="mt-2 text-sm">Providing quality healthcare services across India.</p>
        </div>
      </footer>
    </div>
  );
}