import { useState, useRef, ChangeEvent, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ArrowLeft, Edit, User, Upload, Loader2 } from "lucide-react";
import { Label } from "@/components/ui/label";

export default function ProfilePage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user, updateProfile, isLoading } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    name: user?.name || "John Doe",
    email: user?.email || "john.doe@example.com"
  });
  
  // Update form data when user data changes
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || formData.name,
        email: user.email || formData.email
      });
    }
  }, [user]);

  // Function to handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Function to handle file selection and upload
  const handleProfilePictureChange = async (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    
    const file = e.target.files[0];
    
    // Check file type
    if (!file.type.includes('image/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file (JPEG, PNG, etc.)",
        variant: "destructive"
      });
      return;
    }
    
    // Check file size (limit to 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image under 2MB",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setUploadingImage(true);
      
      // Read the file as Data URL for immediate preview
      const reader = new FileReader();
      reader.onloadend = async () => {
        if (typeof reader.result === 'string') {
          // In a real app, you would upload to a server and get a URL back
          // For this app, we'll use the data URL directly (not optimal for production)
          await updateProfile({ profilePicture: reader.result });
        }
        setUploadingImage(false);
      };
      reader.readAsDataURL(file);
      
    } catch (error) {
      setUploadingImage(false);
      toast({
        title: "Upload Failed",
        description: "Failed to upload profile picture. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Function to trigger file input click
  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  // Function to handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await updateProfile({
        name: formData.name,
        email: formData.email
      });
      
      setIsEditing(false);
    } catch (error) {
      // Error is handled in the updateProfile function
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <div className="container mx-auto max-w-3xl">
        <Button
          variant="ghost"
          className="mb-6 text-blue-600"
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <Card className="shadow-lg border-0">
          <CardHeader className="bg-blue-600 text-white rounded-t-lg">
            <CardTitle className="text-2xl font-bold">My Profile</CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-8">
              {/* Profile Image */}
              <div className="flex flex-col items-center">
                <div className="relative group">
                  <div className="w-32 h-32 rounded-full bg-blue-100 flex items-center justify-center overflow-hidden">
                    {uploadingImage ? (
                      <div className="absolute inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-10">
                        <Loader2 className="h-8 w-8 text-white animate-spin" />
                      </div>
                    ) : null}
                    <img
                      src={user?.profilePicture || "https://img.freepik.com/free-photo/portrait-smiling-young-man-eyewear_171337-4842.jpg"}
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* Hidden file input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleProfilePictureChange}
                  />
                  
                  {/* Upload button overlay */}
                  <button
                    type="button"
                    onClick={triggerFileInput}
                    disabled={isLoading || uploadingImage}
                    className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors"
                  >
                    <Upload className="h-4 w-4" />
                  </button>
                </div>
                <p className="mt-4 text-sm text-gray-500">Profile Picture</p>
                <button
                  type="button"
                  onClick={triggerFileInput}
                  disabled={isLoading || uploadingImage}
                  className="mt-2 text-xs text-blue-600 hover:underline"
                >
                  Change Photo
                </button>
              </div>
              
              {/* Profile Information */}
              <div className="flex-1">
                {isEditing ? (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="border-gray-300"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="border-gray-300"
                      />
                    </div>
                    
                    <div className="flex justify-end gap-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        className="border-gray-300"
                        onClick={() => setIsEditing(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          'Save Changes'
                        )}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-sm text-gray-500 mb-1">Full Name</h3>
                      <p className="text-lg font-medium">{formData.name}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm text-gray-500 mb-1">Email Address</h3>
                      <p className="text-lg">{formData.email}</p>
                    </div>
                    
                    <Button
                      onClick={() => setIsEditing(true)}
                      className="bg-blue-600 hover:bg-blue-700 mt-4"
                    >
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Profile
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="bg-gray-50 rounded-b-lg flex justify-between items-center py-4 px-6">
            <p className="text-sm text-gray-500">
              Member since: {new Date().toLocaleDateString()}
            </p>
            <Button
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50"
              onClick={() => setLocation("/")}
            >
              Return to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}