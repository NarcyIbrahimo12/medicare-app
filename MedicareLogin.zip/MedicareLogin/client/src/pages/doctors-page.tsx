import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  CalendarPlus,
  User,
  LogOut,
  Settings,
  BookOpen,
  Award,
  Calendar,
  MapPin,
  Clock,
  Filter,
} from "lucide-react";

// Define doctor interface
interface Doctor {
  id: number;
  name: string;
  specialty: string;
  experience: string;
  availability: string;
  location: string;
  rating: number;
}

// List of available doctors
const doctors: Doctor[] = [
  {
    id: 1,
    name: "Dr. Anil Kumar",
    specialty: "General Physician",
    experience: "15+ years",
    availability: "Mon, Wed, Fri",
    location: "Apollo Hospital, Delhi",
    rating: 4.8,
  },
  {
    id: 2,
    name: "Dr. Priya Sharma",
    specialty: "Gynecologist",
    experience: "12+ years",
    availability: "Tue, Thu, Sat",
    location: "Fortis Hospital, Mumbai",
    rating: 4.9,
  },
  {
    id: 3,
    name: "Dr. Ramesh Iyer",
    specialty: "Pediatrician",
    experience: "10+ years",
    availability: "Mon to Fri",
    location: "KIMS, Hyderabad",
    rating: 4.7,
  },
  {
    id: 4,
    name: "Dr. Mehul Shah",
    specialty: "Dermatologist",
    experience: "8+ years",
    availability: "Wed to Sun",
    location: "Max Hospital, Noida",
    rating: 4.6,
  },
  {
    id: 5,
    name: "Dr. Neha Kapoor",
    specialty: "Cardiologist",
    experience: "14+ years",
    availability: "Mon, Tue, Thu, Fri",
    location: "Medanta, Gurugram",
    rating: 4.9,
  },
  {
    id: 6,
    name: "Dr. Arjun Rao",
    specialty: "Orthopedic",
    experience: "11+ years",
    availability: "Mon to Sat",
    location: "Manipal Hospital, Bengaluru",
    rating: 4.7,
  },
  {
    id: 7,
    name: "Dr. Ananya Singh",
    specialty: "Psychologist",
    experience: "9+ years",
    availability: "Tue, Thu, Sat, Sun",
    location: "AIIMS, Delhi",
    rating: 4.5,
  },
  {
    id: 8,
    name: "Dr. Vivek Menon",
    specialty: "Neurologist",
    experience: "16+ years",
    availability: "Mon, Wed, Fri",
    location: "Narayana Health, Kolkata",
    rating: 4.8,
  },
  {
    id: 9,
    name: "Dr. Kavita Jain",
    specialty: "Infectious Diseases",
    experience: "13+ years",
    availability: "Tue to Sat",
    location: "Ruby Hall Clinic, Pune",
    rating: 4.6,
  },
  {
    id: 10,
    name: "Dr. Rahul Desai",
    specialty: "Urologist",
    experience: "12+ years",
    availability: "Mon, Wed, Fri, Sat",
    location: "Lilavati Hospital, Mumbai",
    rating: 4.7,
  },
];

// Get unique specialties for filter
const specialtySet = new Set<string>();
doctors.forEach(doctor => specialtySet.add(doctor.specialty));
const specialties = Array.from(specialtySet);

const locationSet = new Set<string>();
doctors.forEach(doctor => locationSet.add(doctor.location.split(",")[0].trim()));
const locations = Array.from(locationSet);

export default function DoctorsPage() {
  const [, setLocation] = useLocation();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [specialtyFilter, setSpecialtyFilter] = useState<string>("");
  const [hospitalFilter, setHospitalFilter] = useState<string>("");

  // Filter doctors based on selected filters
  const filteredDoctors = doctors.filter(doctor => {
    // Apply specialty filter
    if (specialtyFilter && specialtyFilter !== "all" && doctor.specialty !== specialtyFilter) {
      return false;
    }
    
    // Apply hospital filter
    if (hospitalFilter && hospitalFilter !== "all" && !doctor.location.includes(hospitalFilter)) {
      return false;
    }
    
    return true;
  });

  const handleDoctorSelect = (doctor: Doctor) => {
    setSelectedDoctor(doctor);
    // In a real app, you might save the selected doctor to context/state
    // or redirect to the appointment booking page with the doctor ID
    
    // For now, we'll just show a confirmation that the doctor was selected
    setTimeout(() => {
      setLocation("/appointment");
    }, 500);
  };

  const clearFilters = () => {
    setSpecialtyFilter("");
    setHospitalFilter("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white shadow-md py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/home")}
              className="mr-2"
            >
              <ArrowLeft className="h-5 w-5 text-blue-600" />
            </Button>
            <h1 className="text-2xl font-bold text-blue-600">Medicare</h1>
          </div>
          
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 transition-colors"
            >
              <User className="h-6 w-6 text-blue-600" />
            </button>
            
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-20 border border-gray-100">
                <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </button>
                <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </button>
                <hr className="my-1 border-gray-200" />
                <button className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 w-full text-left">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Page title */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Available Doctors</h2>
          <p className="text-gray-600">Select a doctor to book your appointment</p>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-lg shadow-md mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-blue-600 mr-2" />
              <span className="text-gray-700 font-medium">Filter by:</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full md:w-auto">
              <div className="w-full sm:w-48">
                <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Specialty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem key="all-specialties" value="all">All Specialties</SelectItem>
                    {specialties.map((specialty) => (
                      <SelectItem key={specialty} value={specialty}>
                        {specialty}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full sm:w-48">
                <Select value={hospitalFilter} onValueChange={setHospitalFilter}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Hospital" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem key="all-hospitals" value="all">All Hospitals</SelectItem>
                    {locations.map((location) => (
                      <SelectItem key={location} value={location}>
                        {location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button 
              variant="outline" 
              onClick={clearFilters}
              className="w-full md:w-auto"
              disabled={!specialtyFilter && !hospitalFilter || (specialtyFilter === "all" && hospitalFilter === "all")}
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Doctors List */}
        {filteredDoctors.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDoctors.map((doctor) => (
              <Card 
                key={doctor.id} 
                className="overflow-hidden border border-gray-200 hover:border-blue-300 transition-all hover:shadow-md"
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl font-bold text-blue-700">{doctor.name}</CardTitle>
                      <CardDescription className="flex items-center mt-1">
                        <BookOpen className="h-4 w-4 mr-1 text-blue-600" />
                        {doctor.specialty}
                      </CardDescription>
                    </div>
                    <div className="flex items-center bg-blue-50 px-2 py-1 rounded-full">
                      <Award className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm font-semibold text-blue-700">{doctor.rating}</span>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pb-4">
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-500" />
                      <span>{doctor.experience} experience</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                      <span>Available: {doctor.availability}</span>
                    </div>
                    <div className="flex items-start">
                      <MapPin className="h-4 w-4 mr-2 text-gray-500 mt-0.5" />
                      <span>{doctor.location}</span>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="bg-gray-50 border-t border-gray-100 py-3">
                  <Button 
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleDoctorSelect(doctor)}
                  >
                    <CalendarPlus className="h-4 w-4 mr-2" />
                    Select Doctor
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
            <div className="text-gray-500 mb-4">
              <Filter className="h-12 w-12 mx-auto text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-700 mb-2">No doctors found</h3>
            <p className="text-gray-500 mb-4">Try adjusting your filters to find available doctors.</p>
            <Button onClick={clearFilters} variant="outline">Clear Filters</Button>
          </div>
        )}

        {/* Navigation buttons */}
        <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-between">
          <Button 
            variant="outline" 
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
            onClick={() => setLocation("/home")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => setLocation("/appointment")}
            disabled={!selectedDoctor}
          >
            <CalendarPlus className="h-4 w-4 mr-2" />
            Proceed to Booking
          </Button>
        </div>
      </main>

      <footer className="bg-gray-50 py-8 border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; {new Date().getFullYear()} Medicare. All rights reserved.</p>
          <p className="mt-2 text-sm">Providing quality healthcare services across India.</p>
        </div>
      </footer>
    </div>
  );
}