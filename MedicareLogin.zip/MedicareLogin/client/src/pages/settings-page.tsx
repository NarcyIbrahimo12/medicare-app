import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/hooks/use-theme";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ArrowLeft, Save, Moon, Sun } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SettingsPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { theme: currentTheme, setTheme: setGlobalTheme } = useTheme();
  
  // State for settings
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState("english");
  const [themeMode, setThemeMode] = useState(currentTheme);
  
  // Update local state when global theme changes
  useEffect(() => {
    setThemeMode(currentTheme);
  }, [currentTheme]);

  // Function to handle theme change
  const handleThemeChange = (newTheme: "light" | "dark") => {
    setThemeMode(newTheme);
    setGlobalTheme(newTheme);
  };

  // Function to handle form submission
  const handleSaveSettings = () => {
    // Apply theme change if it was changed
    if (themeMode !== currentTheme) {
      setGlobalTheme(themeMode);
    }
    
    // Here you would typically call an API to save other user settings
    toast({
      title: "Settings Updated",
      description: "Your preferences have been successfully saved."
    });
  };

  return (
    <div className="min-h-screen bg-background p-4 transition-colors">
      <div className="container mx-auto max-w-3xl">
        <Button
          variant="ghost"
          className="mb-6 text-primary"
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>

        <Card className="shadow-lg border-0">
          <CardHeader className="bg-primary text-white rounded-t-lg">
            <CardTitle className="text-2xl font-bold">Settings</CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6 space-y-8">
            {/* Notification Preferences */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Notification Preferences</h3>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications" className="text-base">
                    Enable Notifications
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Receive updates about your appointments and medical records
                  </p>
                </div>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={setNotifications}
                  className="data-[state=checked]:bg-primary"
                />
              </div>
            </div>
            
            {/* Language Selection */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Language</h3>
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-4 sm:col-span-2">
                  <Label htmlFor="language" className="text-base mb-2 block">
                    Select Language
                  </Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger id="language" className="w-full">
                      <SelectValue placeholder="Select Language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="hindi">Hindi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            {/* Theme Mode */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Theme</h3>
              <div className="grid grid-cols-2 gap-4 max-w-md">
                <div
                  className={`border rounded-lg p-4 cursor-pointer text-center transition-all ${
                    themeMode === "light"
                      ? "bg-blue-50 border-primary text-primary dark:bg-blue-900"
                      : "border-muted hover:bg-muted/20"
                  }`}
                  onClick={() => handleThemeChange("light")}
                >
                  <div className="h-16 bg-white dark:bg-slate-100 border rounded-md mb-2 flex items-center justify-center">
                    <Sun className="w-8 h-8 text-primary" />
                  </div>
                  <span className="font-medium">Light Mode</span>
                </div>
                
                <div
                  className={`border rounded-lg p-4 cursor-pointer text-center transition-all ${
                    themeMode === "dark"
                      ? "bg-blue-50 border-primary text-primary dark:bg-blue-900"
                      : "border-muted hover:bg-muted/20" 
                  }`}
                  onClick={() => handleThemeChange("dark")}
                >
                  <div className="h-16 bg-gray-800 border rounded-md mb-2 flex items-center justify-center">
                    <Moon className="w-8 h-8 text-blue-400" />
                  </div>
                  <span className="font-medium">Dark Mode</span>
                </div>
              </div>
              
              {/* Theme Switch */}
              <div className="flex items-center gap-4 mt-4">
                <div className="flex flex-grow items-center justify-between p-4 rounded-lg border">
                  <div className="flex items-center gap-3">
                    {themeMode === 'dark' ? (
                      <Moon className="h-5 w-5 text-primary" />
                    ) : (
                      <Sun className="h-5 w-5 text-primary" />
                    )}
                    <span>
                      {themeMode === 'dark' ? 'Dark' : 'Light'} Mode
                    </span>
                  </div>
                  
                  <Switch
                    checked={themeMode === 'dark'}
                    onCheckedChange={(checked) => handleThemeChange(checked ? 'dark' : 'light')}
                    className="data-[state=checked]:bg-primary"
                  />
                </div>
              </div>
            </div>
            
            {/* Save Button */}
            <div className="flex justify-end">
              <Button 
                onClick={handleSaveSettings}
                variant="default"
              >
                <Save className="mr-2 h-4 w-4" />
                Save Settings
              </Button>
            </div>
          </CardContent>
          
          <CardFooter className="bg-muted/50 rounded-b-lg flex justify-between items-center py-4 px-6">
            <p className="text-sm text-muted-foreground">
              Your settings are automatically synced across devices
            </p>
            <Button
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
              onClick={() => setLocation("/")}
            >
              Return to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}