import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { 
  ArrowLeft, 
  User, 
  LogOut, 
  Settings, 
  CalendarClock, 
  Clock, 
  MapPin, 
  Stethoscope, 
  Building,
  Clipboard,
  CheckCircle 
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

// List of doctors
const doctors = [
  { id: 1, name: "Dr. Anil Kumar", specialty: "General Physician" },
  { id: 2, name: "Dr. Priya Sharma", specialty: "Gynecologist" },
  { id: 3, name: "Dr. Ramesh Iyer", specialty: "Pediatrician" },
  { id: 4, name: "Dr. Mehul Shah", specialty: "Dermatologist" },
  { id: 5, name: "Dr. Neha Kapoor", specialty: "Cardiologist" },
  { id: 6, name: "Dr. Arjun Rao", specialty: "Orthopedic" },
  { id: 7, name: "Dr. Ananya Singh", specialty: "Psychologist" },
  { id: 8, name: "Dr. Vivek Menon", specialty: "Neurologist" },
  { id: 9, name: "Dr. Kavita Jain", specialty: "Infectious Diseases" },
  { id: 10, name: "Dr. Rahul Desai", specialty: "Urologist" },
];

// List of hospitals
const hospitals = [
  { id: 1, name: "AIIMS", location: "Delhi" },
  { id: 2, name: "Apollo Hospitals", location: "Chennai" },
  { id: 3, name: "Fortis Hospital", location: "Mumbai" },
  { id: 4, name: "Manipal Hospital", location: "Bengaluru" },
  { id: 5, name: "Medanta", location: "Gurugram" },
  { id: 6, name: "KIMS", location: "Hyderabad" },
  { id: 7, name: "Max Hospital", location: "Noida" },
  { id: 8, name: "Narayana Health", location: "Kolkata" },
  { id: 9, name: "Ruby Hall Clinic", location: "Pune" },
  { id: 10, name: "Sir Ganga Ram Hospital", location: "Delhi" },
];

// List of possible illness types
const illnessTypes = [
  "Fever",
  "Headache",
  "Cough & Cold",
  "Skin Issues",
  "Joint Pain",
  "Digestive Issues",
  "Cardiac Checkup",
  "Neurological Issues",
  "Prenatal Care",
  "Vaccination",
  "Annual Checkup",
  "Other",
];

// Time slots
const timeSlots = [
  "09:00 AM",
  "09:30 AM",
  "10:00 AM",
  "10:30 AM",
  "11:00 AM",
  "11:30 AM",
  "12:00 PM",
  "12:30 PM",
  "02:00 PM",
  "02:30 PM",
  "03:00 PM",
  "03:30 PM",
  "04:00 PM",
  "04:30 PM",
  "05:00 PM",
  "05:30 PM",
];

// Sample booked appointments to simulate unavailable slots
// In a real app, these would come from a database
const bookedAppointments = [
  { doctorId: 1, date: "2025-04-09", time: "10:00 AM" },
  { doctorId: 2, date: "2025-04-09", time: "11:30 AM" },
  { doctorId: 5, date: "2025-04-10", time: "02:30 PM" },
];

// Create form schema with validation
const appointmentFormSchema = z.object({
  doctorId: z.string().min(1, "Please select a doctor"),
  illnessType: z.string().min(1, "Please select or enter an illness type"),
  hospitalId: z.string().min(1, "Please select a hospital"),
  appointmentDate: z.date({
    required_error: "Please select a date for the appointment",
  }),
  appointmentTime: z.string().min(1, "Please select an appointment time"),
});

type AppointmentFormValues = z.infer<typeof appointmentFormSchema>;

export default function AppointmentPage() {
  const [, setLocation] = useLocation();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const { toast } = useToast();

  // Initialize form with default values
  const form = useForm<AppointmentFormValues>({
    resolver: zodResolver(appointmentFormSchema),
    defaultValues: {
      doctorId: "",
      illnessType: "",
      hospitalId: "",
      appointmentTime: "",
    },
  });

  // Watch for changes in doctor and date to update available time slots
  const watchDoctorId = form.watch("doctorId");
  const watchAppointmentDate = form.watch("appointmentDate");

  // When doctor or date changes, clear any selected time
  const handleDoctorChange = (value: string) => {
    setSelectedDoctorId(value);
    form.setValue("doctorId", value);
    form.setValue("appointmentTime", ""); // Clear selected time
  };

  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      form.setValue("appointmentDate", date);
      form.setValue("appointmentTime", ""); // Clear selected time
    }
  };

  // Check if a time slot is available
  const isTimeSlotAvailable = (timeSlot: string) => {
    if (!selectedDoctorId || !selectedDate) return true;
    
    const dateString = format(selectedDate, "yyyy-MM-dd");
    
    return !bookedAppointments.some(
      appointment => 
        appointment.doctorId === parseInt(selectedDoctorId) && 
        appointment.date === dateString && 
        appointment.time === timeSlot
    );
  };

  // Filter available time slots
  const availableTimeSlots = timeSlots.filter(isTimeSlotAvailable);

  const onSubmit = async (data: AppointmentFormValues) => {
    console.log("Appointment data:", data);
    
    try {
      // Find the selected doctor to get their name and specialty
      const selectedDoctor = doctors.find(
        (doctor) => doctor.id === parseInt(data.doctorId)
      );
      
      // Find the selected hospital to get its name and location
      const selectedHospital = hospitals.find(
        (hospital) => hospital.id === parseInt(data.hospitalId)
      );
      
      if (!selectedDoctor || !selectedHospital) {
        throw new Error("Invalid doctor or hospital selection");
      }
      
      // Create appointment data for API
      const appointmentData = {
        userId: 1, // Using default user ID
        doctorId: parseInt(data.doctorId),
        doctorName: selectedDoctor.name,
        specialty: selectedDoctor.specialty,
        hospitalId: parseInt(data.hospitalId),
        hospitalName: selectedHospital.name,
        hospitalLocation: selectedHospital.location,
        illnessType: data.illnessType,
        appointmentDate: format(data.appointmentDate, "yyyy-MM-dd"),
        appointmentTime: data.appointmentTime,
        status: "confirmed"
      };
      
      console.log("Sending appointment data:", appointmentData);
      
      // Send appointment data to API using apiRequest
      const response = await apiRequest("POST", "/api/appointments", appointmentData);
      
      console.log("API response status:", response.status);
      
      if (!response.ok) {
        throw new Error("Failed to schedule appointment");
      }
      
      const savedAppointment = await response.json();
      
      // Invalidate the appointments query cache so the appointments list will refresh
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      console.log("Appointment saved:", savedAppointment);
      
      // Show success message and update UI
      setIsFormSubmitted(true);
      
      toast({
        title: "Appointment Scheduled",
        description: "Your appointment has been successfully scheduled.",
        variant: "default",
      });
    } catch (error) {
      console.error("Error scheduling appointment:", error);
      
      // Get more detailed error message if possible
      let errorMessage = "Failed to schedule appointment. Please try again.";
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  // If the form is submitted, show a confirmation page
  if (isFormSubmitted) {
    const selectedDoctor = doctors.find(d => d.id === parseInt(form.getValues("doctorId")));
    const selectedHospital = hospitals.find(h => h.id === parseInt(form.getValues("hospitalId")));
    
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-white shadow-md py-4 px-6">
          <div className="container mx-auto flex justify-between items-center">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/home")}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5 text-blue-600" />
              </Button>
              <h1 className="text-2xl font-bold text-blue-600">Medicare</h1>
            </div>
            
            <div className="relative">
              <button
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 transition-colors"
              >
                <User className="h-6 w-6 text-blue-600" />
              </button>
              
              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-20 border border-gray-100">
                  <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </button>
                  <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </button>
                  <hr className="my-1 border-gray-200" />
                  <button className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 w-full text-left">
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto">
            <div className="text-center mb-8">
              <div className="inline-block p-4 bg-green-100 rounded-full mb-4">
                <CheckCircle className="h-12 w-12 text-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-2">Appointment Confirmed</h2>
              <p className="text-gray-600">Your appointment has been successfully scheduled</p>
            </div>
            
            <Card className="mb-6 border-0 shadow-md">
              <CardHeader className="pb-2 bg-blue-600 text-white rounded-t-lg">
                <CardTitle className="text-xl">Appointment Details</CardTitle>
              </CardHeader>
              
              <CardContent className="pt-6 space-y-4">
                <div className="flex items-start">
                  <Stethoscope className="h-5 w-5 mr-3 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-gray-700">Doctor</h4>
                    <p className="text-gray-800">{selectedDoctor?.name}</p>
                    <p className="text-sm text-gray-500">{selectedDoctor?.specialty}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Building className="h-5 w-5 mr-3 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-gray-700">Hospital</h4>
                    <p className="text-gray-800">{selectedHospital?.name}</p>
                    <p className="text-sm text-gray-500">{selectedHospital?.location}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Clipboard className="h-5 w-5 mr-3 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-gray-700">Reason</h4>
                    <p className="text-gray-800">{form.getValues("illnessType")}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <CalendarClock className="h-5 w-5 mr-3 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-gray-700">Date & Time</h4>
                    <p className="text-gray-800">
                      {format(form.getValues("appointmentDate"), "MMMM d, yyyy")}
                    </p>
                    <p className="text-gray-800">{form.getValues("appointmentTime")}</p>
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex flex-col gap-3">
                <p className="text-xs text-gray-500 mb-2">A confirmation email with these details has been sent to your registered email address.</p>
                
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => setLocation("/home")}
                >
                  Return to Home
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full border-blue-600 text-blue-600 hover:bg-blue-50 mb-2"
                  onClick={() => setIsFormSubmitted(false)}
                >
                  Book Another Appointment
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full border-green-600 text-green-600 hover:bg-green-50"
                  onClick={() => setLocation("/appointments")}
                >
                  View All Appointments
                </Button>
              </CardFooter>
            </Card>
          </div>
        </main>

        <footer className="bg-gray-50 py-8 border-t border-gray-200 mt-12">
          <div className="container mx-auto px-4 text-center text-gray-600">
            <p>&copy; {new Date().getFullYear()} Medicare. All rights reserved.</p>
            <p className="mt-2 text-sm">Providing quality healthcare services across India.</p>
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white shadow-md py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/doctors")}
              className="mr-2"
            >
              <ArrowLeft className="h-5 w-5 text-blue-600" />
            </Button>
            <h1 className="text-2xl font-bold text-blue-600">Medicare</h1>
          </div>
          
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 transition-colors"
            >
              <User className="h-6 w-6 text-blue-600" />
            </button>
            
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-20 border border-gray-100">
                <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </button>
                <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </button>
                <hr className="my-1 border-gray-200" />
                <button className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 w-full text-left">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Book an Appointment</h2>
            <p className="text-gray-600">Schedule your visit with our specialists</p>
          </div>

          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-2 bg-blue-600 text-white rounded-t-lg">
              <CardTitle className="text-xl">Appointment Details</CardTitle>
              <CardDescription className="text-blue-100">
                Please fill in all the required information
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Doctor Selection */}
                  <FormField
                    control={form.control}
                    name="doctorId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center text-gray-700">
                          <Stethoscope className="h-4 w-4 mr-2 text-blue-600" />
                          Select Doctor
                        </FormLabel>
                        <Select
                          onValueChange={handleDoctorChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Choose a doctor" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {doctors.map((doctor) => (
                              <SelectItem
                                key={doctor.id}
                                value={doctor.id.toString()}
                              >
                                <div className="flex flex-col">
                                  <span>{doctor.name}</span>
                                  <span className="text-xs text-gray-500">{doctor.specialty}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Illness Type */}
                  <FormField
                    control={form.control}
                    name="illnessType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center text-gray-700">
                          <Clipboard className="h-4 w-4 mr-2 text-blue-600" />
                          Type of Illness/Reason
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select reason for visit" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {illnessTypes.map((illness) => (
                              <SelectItem
                                key={illness}
                                value={illness}
                              >
                                {illness}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Or enter custom reason below
                        </FormDescription>
                        <Input
                          placeholder="Or type your reason here"
                          onChange={(e) => {
                            if (e.target.value) {
                              field.onChange(e.target.value);
                            }
                          }}
                          className="mt-2"
                        />
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Hospital Selection */}
                  <FormField
                    control={form.control}
                    name="hospitalId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center text-gray-700">
                          <Building className="h-4 w-4 mr-2 text-blue-600" />
                          Select Hospital
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Choose a hospital" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {hospitals.map((hospital) => (
                              <SelectItem
                                key={hospital.id}
                                value={hospital.id.toString()}
                              >
                                <div className="flex flex-col">
                                  <span>{hospital.name}</span>
                                  <span className="text-xs text-gray-500">{hospital.location}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Separator />

                  {/* Date and Time Selection */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Date Picker */}
                    <FormField
                      control={form.control}
                      name="appointmentDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel className="flex items-center text-gray-700">
                            <CalendarClock className="h-4 w-4 mr-2 text-blue-600" />
                            Appointment Date
                          </FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={`w-full pl-3 text-left font-normal ${
                                    !field.value && "text-muted-foreground"
                                  }`}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={handleDateChange}
                                disabled={(date) =>
                                  date < new Date(new Date().setHours(0, 0, 0, 0)) ||
                                  date > new Date(new Date().setMonth(new Date().getMonth() + 3))
                                }
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Time Picker */}
                    <FormField
                      control={form.control}
                      name="appointmentTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center text-gray-700">
                            <Clock className="h-4 w-4 mr-2 text-blue-600" />
                            Appointment Time
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            disabled={!watchDoctorId || !watchAppointmentDate}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder={
                                  !watchDoctorId || !watchAppointmentDate
                                    ? "Select doctor and date first"
                                    : "Select a time slot"
                                } />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableTimeSlots.length > 0 ? (
                                availableTimeSlots.map((timeSlot) => (
                                  <SelectItem key={timeSlot} value={timeSlot}>
                                    {timeSlot}
                                  </SelectItem>
                                ))
                              ) : (
                                <div className="p-2 text-center text-gray-500">
                                  No available slots for this day
                                </div>
                              )}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Only available time slots are shown
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="pt-4 flex flex-col gap-4">
                    <Button 
                      type="submit" 
                      className="w-full bg-blue-600 hover:bg-blue-700 py-6"
                    >
                      Confirm Appointment
                    </Button>
                    
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setLocation("/home")}
                      className="border-blue-600 text-blue-600 hover:bg-blue-50"
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back to Home
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="bg-gray-50 py-8 border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; {new Date().getFullYear()} Medicare. All rights reserved.</p>
          <p className="mt-2 text-sm">Providing quality healthcare services across India.</p>
        </div>
      </footer>
    </div>
  );
}