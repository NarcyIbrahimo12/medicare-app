import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signupSchema } from "@/lib/auth-validation";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2, User, Mail, Phone, Lock, Eye, EyeOff } from "lucide-react";
import type { SignupFormValues } from "@/lib/auth-validation";

export default function SignupPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phoneNumber: "",
      password: "",
      confirmPassword: "",
    },
  });

  const signupMutation = useMutation({
    mutationFn: async (data: SignupFormValues) => {
      const response = await apiRequest("POST", "/api/signup", data);
      return response.json();
    },
    onSuccess: () => {
      setStatusMessage({ 
        type: 'success', 
        message: 'Account created successfully! Redirecting to home page...' 
      });
      
      // Redirect to homepage after a short delay
      setTimeout(() => {
        setLocation("/home");
      }, 1500);
    },
    onError: (error) => {
      setStatusMessage({ 
        type: 'error', 
        message: 'Failed to create account. Please try again.' 
      });
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SignupFormValues) => {
    // Remove confirmPassword from the data sent to the server
    const { confirmPassword, ...signupData } = data;
    signupMutation.mutate(data);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  return (
    <main className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-b from-blue-50 to-white">
      <div className="w-full max-w-lg">
        <header className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-blue-600">Medicare</h1>
          <p className="mt-2 text-gray-600">Your Health, Our Priority</p>
        </header>

        <Card className="w-full overflow-hidden border-0 shadow-lg rounded-xl">
          <div className="p-1 bg-blue-600" />
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Create Your Medicare Account</h2>
            
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              {/* Full Name Field */}
              <div className="space-y-1">
                <Label 
                  htmlFor="fullName" 
                  className="text-sm font-medium text-gray-700"
                >
                  Full Name
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="John Doe"
                    className="w-full pl-10 py-2 bg-white border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    {...register("fullName")}
                  />
                </div>
                {errors.fullName && (
                  <p className="text-sm text-red-500 mt-1">{errors.fullName.message}</p>
                )}
              </div>

              {/* Email Field */}
              <div className="space-y-1">
                <Label 
                  htmlFor="email" 
                  className="text-sm font-medium text-gray-700"
                >
                  Email Address
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    className="w-full pl-10 py-2 bg-white border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    {...register("email")}
                  />
                </div>
                {errors.email && (
                  <p className="text-sm text-red-500 mt-1">{errors.email.message}</p>
                )}
              </div>

              {/* Phone Number Field */}
              <div className="space-y-1">
                <Label 
                  htmlFor="phoneNumber" 
                  className="text-sm font-medium text-gray-700"
                >
                  Phone Number
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    id="phoneNumber"
                    type="tel"
                    placeholder="(123) 456-7890"
                    className="w-full pl-10 py-2 bg-white border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    {...register("phoneNumber")}
                  />
                </div>
                {errors.phoneNumber && (
                  <p className="text-sm text-red-500 mt-1">{errors.phoneNumber.message}</p>
                )}
              </div>

              {/* Password Field */}
              <div className="space-y-1">
                <Label 
                  htmlFor="password" 
                  className="text-sm font-medium text-gray-700"
                >
                  Password
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2 bg-white border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    {...register("password")}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-sm text-red-500 mt-1">{errors.password.message}</p>
                )}
              </div>

              {/* Confirm Password Field */}
              <div className="space-y-1">
                <Label 
                  htmlFor="confirmPassword" 
                  className="text-sm font-medium text-gray-700"
                >
                  Confirm Password
                </Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2 bg-white border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    {...register("confirmPassword")}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                    onClick={toggleConfirmPasswordVisibility}
                  >
                    {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-sm text-red-500 mt-1">{errors.confirmPassword.message}</p>
                )}
              </div>

              <div className="pt-4">
                <Button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-blue-600 text-white font-medium rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
                  disabled={signupMutation.isPending}
                >
                  {signupMutation.isPending ? (
                    <div className="flex items-center justify-center">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating Account...
                    </div>
                  ) : (
                    "Sign Up"
                  )}
                </Button>
              </div>

              {statusMessage && (
                <div 
                  className={`p-4 mt-4 rounded-lg text-center text-sm font-medium ${
                    statusMessage.type === 'success' 
                      ? 'bg-green-50 text-green-800 border border-green-200' 
                      : 'bg-red-50 text-red-800 border border-red-200'
                  }`}
                >
                  {statusMessage.message}
                </div>
              )}
            </form>
          </CardContent>
        </Card>
        
        <div className="mt-6 text-center text-sm text-gray-500">
          Already have an account?{" "}
          <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium hover:underline">
            Log in
          </Link>
        </div>
      </div>
      
      <footer className="mt-8 text-center text-xs text-gray-500">
        &copy; {new Date().getFullYear()} Medicare. All rights reserved.
      </footer>
    </main>
  );
}