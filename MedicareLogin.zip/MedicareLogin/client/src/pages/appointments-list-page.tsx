import { useState } from "react";
import { useLocation } from "wouter";
import { format, parseISO } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import {
  ArrowLeft,
  User,
  LogOut,
  Settings,
  Calendar,
  ClipboardList,
  Building,
  Clock,
  Stethoscope,
  AlertCircle,
  Loader2
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";

// Type definition for appointment
interface Appointment {
  id: number;
  userId: number;
  doctorId: number;
  doctorName: string;
  specialty: string;
  hospitalId: number;
  hospitalName: string;
  hospitalLocation: string | null;
  illnessType: string;
  appointmentDate: string; // ISO date string
  appointmentTime: string;
  status: string;
  createdAt: string; // ISO datetime string
}

export default function AppointmentsListPage() {
  const [, setLocation] = useLocation();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  // Fetch appointments data from API
  const { data: appointments, isLoading, error } = useQuery({
    queryKey: ['/api/appointments'],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Handle the appointments data, ensuring it's an array before sorting
  const sortedAppointments = appointments && Array.isArray(appointments)
    ? [...appointments].sort((a: Appointment, b: Appointment) => 
        new Date(a.appointmentDate).getTime() - new Date(b.appointmentDate).getTime()
      )
    : [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white shadow-md py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/home")}
              className="mr-2"
            >
              <ArrowLeft className="h-5 w-5 text-blue-600" />
            </Button>
            <h1 className="text-2xl font-bold text-blue-600">Medicare</h1>
          </div>
          
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 transition-colors"
            >
              <User className="h-6 w-6 text-blue-600" />
            </button>
            
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-20 border border-gray-100">
                <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </button>
                <button className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 w-full text-left">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </button>
                <hr className="my-1 border-gray-200" />
                <button className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 w-full text-left">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between mb-8">
            <div className="mb-4 md:mb-0">
              <h2 className="text-3xl font-bold text-gray-800 flex items-center gap-2">
                <ClipboardList className="h-8 w-8 text-blue-600" />
                Your Appointments
              </h2>
              <p className="text-gray-600 mt-1">View all your scheduled appointments</p>
            </div>

            <Button 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => setLocation("/appointment")}
            >
              <Calendar className="h-4 w-4 mr-2" />
              Book New Appointment
            </Button>
          </div>

          {/* Loading state */}
          {isLoading && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-12 h-12 text-blue-600 animate-spin mb-4" />
              <p className="text-gray-600">Loading your appointments...</p>
            </div>
          )}

          {/* Error state */}
          {error && !isLoading && (
            <div className="text-center py-16 bg-red-50 rounded-lg border border-red-200">
              <AlertCircle className="h-12 w-12 mx-auto text-red-500 mb-4" />
              <h3 className="text-xl font-medium text-red-700 mb-2">Error loading appointments</h3>
              <p className="text-red-600 mb-6">There was a problem fetching your appointments.</p>
              <Button 
                variant="outline"
                className="mr-2"
                onClick={() => setLocation("/home")}
              >
                Return Home
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => window.location.reload()}
              >
                Try Again
              </Button>
            </div>
          )}

          {/* Appointments list */}
          {!isLoading && !error && sortedAppointments.length > 0 && (
            <div className="space-y-6">
              {sortedAppointments.map((appointment) => (
                <Card 
                  key={appointment.id} 
                  className="overflow-hidden border border-gray-200 hover:border-blue-200 transition-all shadow-md"
                >
                  <CardHeader className="pb-2 bg-gradient-to-r from-blue-50 to-white">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl font-bold text-blue-700 flex items-center">
                          <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                          {format(parseISO(appointment.appointmentDate), "EEEE, MMMM d, yyyy")}
                        </CardTitle>
                        <CardDescription className="text-gray-600 font-medium mt-1">
                          <Clock className="h-4 w-4 inline-block mr-1" />
                          {appointment.appointmentTime}
                        </CardDescription>
                      </div>
                      <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500 mb-1 flex items-center">
                            <Stethoscope className="h-4 w-4 mr-1 text-blue-600" />
                            Doctor
                          </h4>
                          <p className="text-gray-800 font-medium">{appointment.doctorName}</p>
                          <p className="text-sm text-gray-600">{appointment.specialty}</p>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium text-gray-500 mb-1 flex items-center">
                            <Building className="h-4 w-4 mr-1 text-blue-600" />
                            Hospital
                          </h4>
                          <p className="text-gray-800 font-medium">{appointment.hospitalName}</p>
                          <p className="text-sm text-gray-600">{appointment.hospitalLocation}</p>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium text-gray-500 mb-1 flex items-center">
                          <AlertCircle className="h-4 w-4 mr-1 text-blue-600" />
                          Reason for Visit
                        </h4>
                        <p className="text-gray-800">{appointment.illnessType}</p>
                        
                        <Separator className="my-4" />
                        
                        <div className="text-sm text-gray-500">
                          <p>Appointment ID: #{appointment.id}</p>
                          <p>Booked on: {format(new Date(appointment.createdAt), "MMMM d, yyyy")}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Empty state */}
          {!isLoading && !error && sortedAppointments.length === 0 && (
            <div className="text-center py-16 bg-gray-50 rounded-lg border border-gray-200">
              <ClipboardList className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-medium text-gray-700 mb-2">No appointments found</h3>
              <p className="text-gray-500 mb-6">You haven't scheduled any appointments yet.</p>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setLocation("/appointment")}
              >
                Book Your First Appointment
              </Button>
            </div>
          )}

          <div className="mt-8 text-center">
            <Button 
              variant="outline" 
              className="border-blue-600 text-blue-600 hover:bg-blue-50"
              onClick={() => setLocation("/home")}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </div>
      </main>

      <footer className="bg-gray-50 py-8 border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; {new Date().getFullYear()} Medicare. All rights reserved.</p>
          <p className="mt-2 text-sm">Providing quality healthcare services across India.</p>
        </div>
      </footer>
    </div>
  );
}