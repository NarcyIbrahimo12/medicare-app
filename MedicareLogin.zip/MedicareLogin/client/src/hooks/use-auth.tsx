import { createContext, ReactNode, useContext, useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

// Define user type
export interface User {
  id: number;
  name: string;
  email: string;
  profilePicture?: string;
}

// Define authentication context type
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  updateProfile: (profileData: Partial<User>) => Promise<void>;
  logout: () => void;
}

// Create the authentication context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: false,
  login: async () => {},
  register: async () => {},
  updateProfile: async () => {},
  logout: () => {}
});

// Authentication provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Mock login function
  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      
      // In a real application, this would make an API call
      // For now we're simulating a successful login with a slight delay for loading state
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setUser({
        id: 1,
        name: "John Doe",
        email,
        profilePicture: "https://img.freepik.com/free-photo/portrait-smiling-young-man-eyewear_171337-4842.jpg"
      });
      
      setLocation("/home");
      
      toast({
        title: "Welcome back!",
        description: "You have successfully logged in.",
      });
    } catch (error) {
      toast({
        title: "Login failed",
        description: "Please check your credentials and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Mock register function
  const register = async (name: string, email: string, password: string) => {
    try {
      setIsLoading(true);
      
      // In a real application, this would make an API call
      // For now we're simulating a successful registration with a slight delay for loading state
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setUser({
        id: 1,
        name,
        email,
        profilePicture: "https://img.freepik.com/free-photo/portrait-smiling-young-man-eyewear_171337-4842.jpg"
      });
      
      setLocation("/home");
      
      toast({
        title: "Account created",
        description: "Your account has been successfully created.",
      });
    } catch (error) {
      toast({
        title: "Registration failed",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Profile update function
  const updateProfile = async (profileData: Partial<User>) => {
    try {
      setIsLoading(true);
      
      // In a real application, this would make an API call
      // For now we're simulating a successful profile update with a slight delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setUser(prev => {
        if (!prev) return null;
        return { ...prev, ...profileData };
      });
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated.",
      });
      
      return;
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Failed to update your profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    // In a real application, this would make an API call to invalidate the session
    setUser(null);
    setLocation("/");
    
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, updateProfile, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook to use the authentication context
export function useAuth() {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  
  return context;
}