import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

type Theme = "light" | "dark";

type ThemeContextType = {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
};

// Create context with default values
const ThemeContext = createContext<ThemeContextType>({
  theme: "light",
  toggleTheme: () => {},
  setTheme: () => {},
});

// Theme provider component
export function ThemeProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  
  // Initialize theme from localStorage or default to light
  const [theme, setThemeState] = useState<Theme>(() => {
    const savedTheme = localStorage.getItem("medicare-theme");
    return (savedTheme as Theme) || "light";
  });

  // Apply the theme to the document element when it changes
  useEffect(() => {
    const root = document.documentElement;
    
    // Remove both classes to ensure clean state
    root.classList.remove("light", "dark");
    
    // Add current theme class
    root.classList.add(theme);
    
    // Save to localStorage
    localStorage.setItem("medicare-theme", theme);
    
    // Also update the theme.json appearance
    // In a real app, this would be an API call to persist to backend
  }, [theme]);

  // Toggle between light and dark theme
  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setThemeState(newTheme);
    
    toast({
      title: `${newTheme.charAt(0).toUpperCase() + newTheme.slice(1)} Mode Activated`,
      description: `The appearance has been switched to ${newTheme} mode.`,
    });
  };

  // Set a specific theme
  const setTheme = (newTheme: Theme) => {
    if (newTheme !== theme) {
      setThemeState(newTheme);
      
      toast({
        title: `${newTheme.charAt(0).toUpperCase() + newTheme.slice(1)} Mode Activated`,
        description: `The appearance has been switched to ${newTheme} mode.`,
      });
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Hook to use the theme context
export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}