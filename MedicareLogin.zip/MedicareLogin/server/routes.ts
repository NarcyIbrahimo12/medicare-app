import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertAppointmentSchema } from "@shared/schema";

// Login schema for validation
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

// Signup schema for validation
const signupSchema = z.object({
  fullName: z.string().min(1),
  email: z.string().email(),
  phoneNumber: z.string().min(10),
  password: z.string()
    .min(8)
    .regex(/[A-Z]/)
    .regex(/[a-z]/)
    .regex(/[0-9]/)
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Login endpoint
  app.post("/api/login", async (req, res) => {
    try {
      // Validate request body against schema
      const result = loginSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input", 
          errors: result.error.format() 
        });
      }
      
      const { email, password } = result.data;
      
      // In a real app, we would validate credentials against a database
      // For this demo, we'll simulate a successful login
      // This would be replaced with actual user validation in a production app
      
      // For demo purposes, accept any well-formed input
      // In a real implementation, you would check against actual user data
      return res.status(200).json({ 
        success: true,
        user: {
          email
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "An error occurred during login" });
    }
  });

  // Signup endpoint
  app.post("/api/signup", async (req, res) => {
    try {
      // Validate request body against schema
      const result = signupSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input", 
          errors: result.error.format() 
        });
      }
      
      const userData = result.data;
      
      // In a real app, we would:
      // 1. Check if email already exists
      // 2. Hash the password
      // 3. Store the user in a database
      
      // For demo purposes, just return success
      return res.status(201).json({ 
        success: true,
        user: {
          fullName: userData.fullName,
          email: userData.email,
          phoneNumber: userData.phoneNumber
        }
      });
    } catch (error) {
      console.error("Signup error:", error);
      return res.status(500).json({ message: "An error occurred during signup" });
    }
  });

  // Get all appointments for a user
  app.get("/api/appointments", async (req, res) => {
    try {
      // In a real app, you would get the userId from authentication
      // For demo purposes, we'll use a default user ID
      const userId = 1; // Default user ID for demonstration
      
      const appointments = await storage.getAppointments(userId);
      
      return res.status(200).json(appointments);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      return res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  // Get a specific appointment
  app.get("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }
      
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      return res.status(200).json(appointment);
    } catch (error) {
      console.error("Error fetching appointment:", error);
      return res.status(500).json({ message: "Failed to fetch appointment" });
    }
  });

  // Create a new appointment
  app.post("/api/appointments", async (req, res) => {
    try {
      // Validate request body
      const result = insertAppointmentSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid appointment data", 
          errors: result.error.format() 
        });
      }
      
      // In a real app, you would get the userId from authentication
      // For now, we'll use the userId provided in the request or default to 1
      const appointmentData = result.data;
      
      // Create the appointment
      const appointment = await storage.createAppointment(appointmentData);
      
      return res.status(201).json(appointment);
    } catch (error) {
      console.error("Error creating appointment:", error);
      return res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  // Update an appointment
  app.patch("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }
      
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Update the appointment
      const updatedAppointment = await storage.updateAppointment(id, req.body);
      
      return res.status(200).json(updatedAppointment);
    } catch (error) {
      console.error("Error updating appointment:", error);
      return res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  // Delete an appointment
  app.delete("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid appointment ID" });
      }
      
      const appointment = await storage.getAppointment(id);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      await storage.deleteAppointment(id);
      
      return res.status(204).send();
    } catch (error) {
      console.error("Error deleting appointment:", error);
      return res.status(500).json({ message: "Failed to delete appointment" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
